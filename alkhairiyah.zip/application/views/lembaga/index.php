<div class="jbtr">
    <div class="container">
        <h1 class="display-3">Tentang Lembaga</h1>
        <p class="lead">SD Islam Al-Khairiyah Banyuwangi</p>
    </div>
</div>
<div class="container-fluid">
    <div class="card card-2" style="margin-top: -70px">
        <div class="container">
            <div class="row">
                <div class="col d-flex justify-content-center">
                    <img src="<?= base_url('assets/img/') ?>page-under-maintenance.png" class="mx-auto">
                </div>
            </div>
        </div>
    </div>
</div>